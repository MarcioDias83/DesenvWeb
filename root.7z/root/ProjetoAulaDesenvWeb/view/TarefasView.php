<html>
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Clientes</title>
</head>
<body>

    <?php $action = 'inserir';?>

    <h1>Cadastro de Tarefas</h1>
    <form action="../controller/ClienteController.php?<?php echo $action?>" method="POST">
        <label for="id">Id:</label>
        <input type="text" id="id" name="id" required><br><br>

        <label for="descricao">Descricao:</label>
        <input type="email" id="descricao" name="descricao" required><br><br>

        <label for="tipo">Tipo:</label>
        <input type="tel" id="tipo" name="tipo"><br><br>

        <label for="cliente">Cliente:</label>
        <input type="int" id="cliente" name="cliente"><br><br>

        <label for="valor">Valor:</label>
        <input type="float" id="valor" name="valor"><br><br>

        <label for="estado">Estado:</label>
        <input type="text" id="estado" name="estado"><br><br>

        <input type="submit" value="Cadastrar">
    </form>
</body>
</html>