<html>
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Clientes</title>
</head>
<body>

    <?php $action = 'inserir';?>

    <h1>Cadastro de Clientes</h1>
    <form action="../controller/ClienteController.php?<?php echo $action?>" method="POST">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" required><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>

        <label for="telefone">Telefone:</label>
        <input type="tel" id="telefone" name="telefone"><br><br>

        <label for="endereco">Endereço:</label>
        <input id="endereco" name="endereco"><br><br>

        <label for="cidade">Cidade:</label>
        <input type="text" id="cidade" name="cidade"><br><br>

        <label for="estado">Estado:</label>
        <input type="text" id="estado" name="estado"><br><br>

        <input type="submit" value="Cadastrar">
    </form>
</body>
</html>