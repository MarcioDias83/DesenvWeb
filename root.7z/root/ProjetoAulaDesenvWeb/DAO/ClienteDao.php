<?php

include_once 'Conexao.php';

class ClienteDao{

    public static function inserirCliente($cliente){

        $sql = "INSERT INTO clientes "
        . "(nome, telefone, email, endereco, estado, cidade) VALUES"
        . " ('".$cliente->getNome()."',"
        . "  '".$cliente->getTelefone()."' , "
        . "  '".$cliente->getEmail()."' , "
        . "  '".$cliente->getEndereco()."' , "
        . "  '".$cliente->getEstado()."' , "
        . "  '".$cliente->getCidade()."'"
        . "  ); ";

        Conexao::executar($sql);
    }
}