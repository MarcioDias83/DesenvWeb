<?php


class Conexao{
    private static function abrir(){
        //nome tem que ser igual a database criada no phpmyadmin
        $nomeDaBaseDeDados = "tarefas";
        //usuário que foi criado na criação do banco (Padrão USBWebServer root)
        $usuario = "root";
        //senha que foi criada na criação do banco (Padrão USBWebServer root)
        $senha = "root";
        //endereço do banco, em aulautilizamos localhost para execução local
        $endereco = "localhost";

        $conexao = mysqli_connect($endereco, $usuario, $senha, $nomeDaBaseDeDados);

        if($conexao){
            return $conexao;
        }
        else{
            return null;
        }
    }

    private static function fechar($conexao){
        mysqli_close($conexao);
    }

    public static function executar($sql){
        $conexao = self::abrir();
        if($conexao){
            mysqli_query($conexao, $sql);
            self::fechar($conexao);
        }
    }


}