<?php

include_once'../model/ClienteModel.php';
include_once'../DAO/ClienteDao.php';

//isset verifica se uma informação existe, está setada
// $_REQUEST busca na url se existe o valor que está entre ['']
if (isset($_REQUEST['inserir'])){

    //Cliente faz referência a ClienteModel.php
    $cliente = new Cliente();
    //$_POST vai buscar no FrmCliente o campo com id que está entre['']
    // para o POST funcionar no FrmCliente o method tem que ser POST
    $cliente->setNome($_POST['nome']);
    $cliente->setEmail($_POST['email']);
    $cliente->setTelefone($_POST['telefone']);
    $cliente->setEndereco($_POST['endereco']);
    $cliente->setCidade($_POST['cidade']);
    $cliente->setEstado($_POST['estado']);

    ClienteDao::inserirCliente($cliente);
}